fx_version 'cerulean'
games { 'gta5' }

author 'DaemonAlex "Schtoop"'
description 'Access control for FivePD functionalities based on QBCore police job.'
version '1.0.0'

server_script 'server.lua'

dependency 'qb-core'